#!/bin/sh
set -eu
exec node scripts/rea.mjs mcp --http --host 0.0.0.0 --port "${PORT:-3000}"
